/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vista;

import javax.swing.*;
import modelo.Usuario;

public class LoginVentana extends JFrame {
    private JTextField usuarioField;
    private JPasswordField contraseñaField;
    private Usuario usuarioDemo;

    public LoginVentana() {
        usuarioDemo = new Usuario("cliente", "1234");

        setTitle("Login Fidness");
        setSize(300, 200);
        setLayout(null);

        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioLabel.setBounds(30, 30, 80, 25);
        add(usuarioLabel);

        usuarioField = new JTextField();
        usuarioField.setBounds(120, 30, 130, 25);
        add(usuarioField);

        JLabel contraseñaLabel = new JLabel("Contraseña:");
        contraseñaLabel.setBounds(30, 70, 80, 25);
        add(contraseñaLabel);

        contraseñaField = new JPasswordField();
        contraseñaField.setBounds(120, 70, 130, 25);
        add(contraseñaField);

        JButton loginButton = new JButton("Ingresar");
        loginButton.setBounds(90, 120, 100, 30);
        add(loginButton);

        loginButton.addActionListener(e -> {
            String usuario = usuarioField.getText();
            String contraseña = new String(contraseñaField.getPassword());

            if (usuarioDemo.iniciarSesion(usuario, contraseña)) {
                JOptionPane.showMessageDialog(this, "Bienvenido " + usuario);
                dispose();
                new MenuPrincipal().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Ingreso incorrecto.");
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new LoginVentana();
    }
}
