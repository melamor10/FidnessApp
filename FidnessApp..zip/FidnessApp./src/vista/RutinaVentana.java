/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import modelo.Ejercicio;

public class RutinaVentana extends JFrame {

    private final JTextField nombreRutinaField;
    private final JPanel ejerciciosPanel;
    private final ArrayList<Ejercicio> rutinaEjercicios;

    public RutinaVentana(ArrayList<Ejercicio> ejerciciosSeleccionados) {
        rutinaEjercicios = new ArrayList<>(ejerciciosSeleccionados);

        setTitle("Crear / Ver Rutina");
        setSize(500, 400);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.add(new JLabel("Nombre de la rutina:"));
        nombreRutinaField = new JTextField(20);
        topPanel.add(nombreRutinaField);

        add(topPanel, BorderLayout.NORTH);

        ejerciciosPanel = new JPanel();
        ejerciciosPanel.setLayout(new BoxLayout(ejerciciosPanel, BoxLayout.Y_AXIS));
        JScrollPane scroll = new JScrollPane(ejerciciosPanel);
        add(scroll, BorderLayout.CENTER);

        JButton guardarButton = new JButton("Guardar Rutina");
        guardarButton.addActionListener(e -> exportarRutina());
        add(guardarButton, BorderLayout.SOUTH);

        cargarEjercicios();

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void cargarEjercicios() {
        ejerciciosPanel.removeAll();

        for (Ejercicio e : rutinaEjercicios) {
            JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            panel.add(new JLabel(e.getNombre()));

            JButton eliminarButton = new JButton("Eliminar");
            eliminarButton.addActionListener(ev -> {
                rutinaEjercicios.remove(e);
                cargarEjercicios();
            });

            panel.add(eliminarButton);
            ejerciciosPanel.add(panel);
        }

        ejerciciosPanel.revalidate();
        ejerciciosPanel.repaint();
    }

    private void exportarRutina() {
        String nombreRutina = nombreRutinaField.getText();
        if (nombreRutina.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar el nombre de la rutina.");
            return;
        }

        try (FileWriter writer = new FileWriter("Rutina_" + nombreRutina + ".txt")) {
            writer.write("Rutina: " + nombreRutina + "\n");
            writer.write("Ejercicios:\n");
            for (Ejercicio e : rutinaEjercicios) {
                writer.write("- " + e.getNombre() + "\n");
            }
            JOptionPane.showMessageDialog(this, "Rutina guardada exitosamente.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al guardar la rutina.");
        }
    }
}