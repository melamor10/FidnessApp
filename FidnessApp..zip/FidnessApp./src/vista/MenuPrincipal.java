/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import modelo.Ejercicio;

public class MenuPrincipal extends JFrame {

    private final JPanel ejerciciosPanel;
    private final ArrayList<Ejercicio> listaEjercicios;
    private String categoriaSeleccionada = "Pierna";

    public MenuPrincipal() {
        setTitle("Menú Principal Fidness");
        setSize(600, 400);
        setLayout(new BorderLayout());

        // Panel superior con botones de categorías
        JPanel categoriasPanel = new JPanel();
        categoriasPanel.setLayout(new FlowLayout());

        String[] categorias = {"Pierna", "Brazo", "Espalda", "Abdomen"};
        for (String categoria : categorias) {
            JButton btn = new JButton(categoria);
            btn.addActionListener(e -> {
                categoriaSeleccionada = categoria;
                cargarEjercicios();
            });
            categoriasPanel.add(btn);
        }

        add(categoriasPanel, BorderLayout.NORTH);

        // Panel central con ejercicios
        ejerciciosPanel = new JPanel();
        ejerciciosPanel.setLayout(new BoxLayout(ejerciciosPanel, BoxLayout.Y_AXIS));
        JScrollPane scroll = new JScrollPane(ejerciciosPanel);
        add(scroll, BorderLayout.CENTER);

        // Simulación de ejercicios iniciales
        listaEjercicios = new ArrayList<>();
        listaEjercicios.add(new Ejercicio("Sentadilla", "Pierna", "Ejercicio básico", "Flexionar rodillas."));
        listaEjercicios.add(new Ejercicio("Press Banca", "Brazo", "Fuerza pectoral", "Empujar barra."));
        listaEjercicios.add(new Ejercicio("Remo", "Espalda", "Fortalece la espalda", "Tirar barra hacia ti."));
        listaEjercicios.add(new Ejercicio("Abdominales", "Abdomen", "Ejercicio básico", "Levantar torso."));

        cargarEjercicios();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void cargarEjercicios() {
        ejerciciosPanel.removeAll();

        for (Ejercicio e : listaEjercicios) {
            if (e.getTipo().equals(categoriaSeleccionada)) {
                JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                panel.add(new JLabel(e.getNombre()));

                JButton verButton = new JButton("Ver instrucciones");
                verButton.addActionListener(ev -> JOptionPane.showMessageDialog(this, e.getInstrucciones()));
                panel.add(verButton);

                JButton agregarButton = new JButton("Agregar a rutina");
                agregarButton.addActionListener(ev -> JOptionPane.showMessageDialog(this, "Ejercicio agregado a la rutina."));
                panel.add(agregarButton);

                ejerciciosPanel.add(panel);
            }
        }

        ejerciciosPanel.revalidate();
        ejerciciosPanel.repaint();
    }
}